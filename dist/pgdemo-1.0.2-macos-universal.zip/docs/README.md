# PostgreSQL Demo Schema Builder (Go + Fyne)

Desktop app that creates a demo schema in a PostgreSQL database.

## Choices in the app

- **Connection**: a login popup at startup asks for host, port, database, user, password and SSL mode. Click **Change connection...** at the top of the window to switch to a different database later.
- **Schema name**: for example `demo`.
- **Schema type**:
  - Webshop: categories, products, customers, orders, order_items
  - HR: departments, employees (with managers), projects, employee_projects
  - Library: authors, books, members, loans
  - School: teachers, courses, students, enrollments
  - Nibble: 36 tables and 81 foreign keys, built to test partial (percentage) schema copies.
    It has composite and natural keys, FKs to UNIQUE (non-PK) columns, 9 self references, a cycle
    (departments <-> employees, deferrable), M:N junctions, CASCADE / SET NULL, skewed data,
    a polymorphic table without FKs (attachments) and a table without relations (app_settings).
    The view `fk_graph` lists every foreign key in the schema. Code: `nibble.go`.
  - Nibble secure: Nibble plus sensitive data, for testing data masking (pgTestBuilder). Use schema
    name `nibble_secure`. Adds `persons` with the BSN (valid 11-check) as natural primary key,
    referenced by `customer_contacts.person_bsn` and `employees.bsn` (UNIQUE), and `vehicles.driver_bsn`
    referencing `employees(bsn)`. Also IBAN (valid mod-97) on customers, suppliers, employees and
    persons, birth dates, password hashes, `payment_cards` (valid Luhn numbers), `vehicles` (Dutch
    license plates), `login_events` (inet IP addresses, IPv4 and IPv6), personal data in JSONB
    (`customer_contacts.details`) and in free text (`ticket_comments.body`). `customer_notes`
    (note_id, customer_id, notes) and `employee_notes` (note_id, employee_id, notes) have free
    text notes, some over several lines, and **no foreign key**: customer_id / employee_id refer
    to customers(id) / employees(id) by convention only, a case for virtual FKs in pgTestBuilder
    (it suggests them). All values are generated.
    Code: `nibble_secure.go`.
  - Nibble secure history: Nibble secure (the same data for the same seed and size) plus five
    **history tables** with the earlier versions of the rows with personal data: `his_persons`,
    `his_customers`, `his_customer_contacts`, `his_employees` and `his_suppliers`. The current
    version stays in the original table; a `his_` table has the versions before it (0 to 3 per
    row, 1.5 on average), each with `version_no`, `valid_from`, `valid_to` (the day the next
    version started, no gaps, all before 2025) and `change_reason` (marriage, moved, new bank
    account, promotion, ...). They hold personal data that is no longer in the current table: old
    names, e-mail addresses, phone numbers, IBANs, addresses and salaries. The `his_` tables are
    **standalone: no foreign keys**. They refer to the current rows by value only (`bsn`,
    `customer_id`, `contact_id`, `employee_id`, `supplier_id`, and `changed_by` to an employee),
    with the same BSN, customer, employee and supplier numbers as the current rows.
    Also as BE / DE / UK (see below). Code: `nibble_history.go`.
  - Nibble enterprise: **three schemas** of one application, with foreign keys between them.
    You enter one name (e.g. `nibent`) and get:
    - `nibent_core`: Nibble secure, unchanged (the same data as Nibble secure for the same seed and size);
    - `nibent_hr` (18 tables): job titles, salary scales, contracts, position history, leave types,
      balances and requests, absences with **medical notes** (health data), **attendance** (one row
      per employee per working day of 2025), overtime, **payslips** for every month of 2025 with
      BSN and IBAN, payslip lines, emergency contacts, ID documents, performance reviews, trainings,
      and `hr_notes` (no FK: employee_id refers to `nibent_core.employees(id)` by convention);
    - `nibent_fleet` (13 tables): lease companies, car models, lease categories (per salary scale),
      cars (unique licence plates and VINs), lease contracts, car assignments, fuel cards and fuel
      transactions (weekly), the **trip log** (about 200 trips per car, with addresses), damages,
      traffic fines (no FK: `license_plate` refers to `cars(license_plate)` by convention; about 5%
      are plates not in the fleet), maintenance and private-use declarations with BSN.

    Foreign keys between the schemas: hr → core (employees, departments, `persons(bsn)` as natural
    key), fleet → core (employees, vehicles, `persons(bsn)`), fleet → hr (salary scales, contracts)
    and hr → fleet (`payslip_lines.lease_contract_id`), so hr and fleet refer to each other.
    The data is consistent across the schemas: employees whose number ends in 1, 4 or 7 drive a
    lease car (30%), their lease category matches the salary scale of their HR contract, and their
    payslips have a "private use company car" line pointing to their lease contract. On a payslip,
    net = salary − pension − wage tax + travel + other allowances.
    Size: about 142 rows per unit (Medium: 142,000; size 1,000,000: about 142 million, of which
    52 million in the core, 74 million in hr and 16 million in fleet).
    Drop existing schema drops all three. Code: `nibble_enterprise.go`.
  - Nibble secure BE / DE / UK, Nibble secure history BE / DE / UK and Nibble enterprise BE / DE / UK: the same tables, keys and rows
    as the Dutch templates, with the personal data of another country and **local column names**
    for the personal data columns (table names stay English). Code: `locale.go`.
    - Values: names, streets, postcodes, towns, mobile numbers, IBAN (valid mod-97, and for BE the
      national check), licence plates (unique ones for the fleet) and the national identification
      number instead of the BSN, unique and valid: BE rijksregisternummer (11 digits, mod-97 check),
      DE Steuer-ID (11 digits, ISO 7064 check digit, one digit twice), UK National Insurance number
      (AB123456C). The ID columns are `char(11)` (BE, DE) or `char(9)` (UK) with a matching CHECK.
    - Column names: DE German (`steuer_id`, `vorname`, `nachname`, `strasse`, `plz`, `ort`,
      `kennzeichen`, `notizen`, ...); UK British (`ni_number`, `forename`, `surname`,
      `address_line_1`, `town`, `registration_plate`, ...); BE mixed like many Belgian systems:
      the customer side (addresses, customers, contacts, payment cards, notes) and the fleet schema
      in French (`prenom`, `nom_de_famille`, `rue`, `code_postal`, `localite`, `numero_national`,
      `plaque`, ...), the employees, persons and HR in Dutch (`voornaam`, `achternaam`,
      `rijksregisternummer`, `nummerplaat`, `opmerkingen`, ...). So `customer_contacts.numero_national`
      refers to `persons.rijksregisternummer`.
    - How: the tables are created and loaded with the original names; at the end of the
      transaction `ALTER TABLE ... RENAME COLUMN` gives the local names. PostgreSQL renames the
      columns in the foreign keys, indexes and views along. Preview SQL lists the renames at the end.
    - The free text (notes, descriptions) stays English, with the local values inside.
    - The Dutch templates are unchanged: the same data for the same seed and size.
- **Drop existing schema** (asks for confirmation; `public` is never dropped).
- **Foreign keys / Indexes / Example views**: on or off.
- **Insert demo data**: yes or no. Size can be Small (100), Medium (1,000), Large (10,000) or Custom (up to 10,000,000).
- **Seed**: leave empty for random data. Enter a number to get the same data every time.
- **Preview SQL**: shows the DDL before you run anything.

Everything runs in one transaction. If there's an error or you click Cancel, nothing is left behind.
Data is loaded with `COPY`, which is fast. Foreign keys and indexes are added after the load.
Data is written with `COPY ... WITH (FREEZE)` (text format): every table is created in the same
transaction that fills it, so PostgreSQL can store the rows already frozen. No VACUUM pass is
needed afterwards, and the first queries on the new data (for example a pgTestBuilder selection)
are not slowed down by PostgreSQL doing that work on the fly. Every table is analyzed before the
commit. Keys and indexes are built with more memory (`maintenance_work_mem` 1GB, `work_mem`
256MB) and up to 4 parallel workers per index, for this transaction only. While the server processes rows, pgdemo already generates the next ones (same data for
the same seed). The log shows per table where the time went, e.g.
`Inserted 90000000 rows into sales_order_lines in 3m28s (generating 1m10s, waiting for the server 2m15s)`:
much "generating" means pgdemo (this computer) is the bottleneck, much "waiting" the server.

## Requirements (macOS)

1. Go 1.22 or newer: https://go.dev/dl
2. Xcode command line tools (Fyne needs a C compiler): `xcode-select --install`

## Build and run

```bash
cd pgdemo
go mod tidy        # downloads fyne.io/fyne/v2 and github.com/jackc/pgx/v5
go run .
```

The first build takes a few minutes because Fyne compiles C code.

To build a standalone app:

```bash
go install fyne.io/tools/cmd/fyne@latest
fyne package --name "PG Demo"   # creates PG Demo.app
```

## Files

| File           | Contents                                              |
|----------------|-------------------------------------------------------|
| `main.go`      | Starts the app                                        |
| `ui.go`        | Fyne window, options, log, progress, dialogs          |
| `db.go`        | Connection, transaction, CREATE/COPY/constraints      |
| `templates.go` | The schema types (tables, DDL, views, row generators) |
| `nibble.go`    | The Nibble schema type (relationship-heavy)           |
| `nibble_secure.go` | Nibble secure: Nibble plus sensitive data         |
| `nibble_history.go` | Nibble secure history: Nibble secure plus `his_` tables |
| `nibble_enterprise.go` | Nibble enterprise: core + HR + fleet, three schemas |
| `locale.go`    | Country versions (BE, DE, UK): values, IDs, column renames |
| `version.go`   | Version (set by the package script) and the app icon (`Icon.png`) |
| `build/package.sh` | Builds the distribution packages (see below) |
| `copytext.go`  | COPY ... WITH (FREEZE) in text format, generating while sending |
| `gen.go`       | Random data helpers and name lists                    |

## Distribution packages

On the Mac, in the pgdemo folder:

```
bash build/package.sh            # version from build/VERSION, mac + windows + linux
bash build/package.sh 1.1.0 mac  # another version, only some targets
```

Output in `dist/`:

| Package | Contents |
|---|---|
| `pgdemo-<version>-macos-universal.zip` | `pgdemo.app` (Apple silicon + Intel), ad-hoc signed |
| `pgdemo-<version>-windows-amd64.zip` | `pgdemo.exe` |
| `pgdemo-<version>-linux-amd64.tar.xz` | binary, icon, desktop entry, `install.sh` |

Each package has `docs/README.md` and `docs/FIRST_START.txt` (how to open an unsigned app the
first time). Requirements are the same as for pgTestBuilder: Xcode command line tools for the
Mac; MinGW-w64 (`brew install mingw-w64`) or Podman + fyne-cross for Windows; Podman +
fyne-cross for Linux (`podman machine start` first). The script builds on the local disk, so the
`._` files on the stick do not end up in the packages.

## Adding your own schema type

Add a function in `templates.go` that returns a `*Template`, the same way `webshop()` does,
and add it to the `Templates` list. Parent tables must come before child tables.
For more than one schema, list the suffixes in `Template.Schemas` (e.g. `"hr"`), set
`Table.Schema` to the suffix, and use `{s_hr}` next to `{s}` in SQL (see `fks` and `idxs`).

The app saves the connection settings, but never the password.
