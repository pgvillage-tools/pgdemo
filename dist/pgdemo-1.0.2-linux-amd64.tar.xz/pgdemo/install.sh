#!/bin/sh
# Installs pgdemo for this user (~/.local) or, with sudo, for everyone (/usr/local).
set -e
cd "$(dirname "$0")"
if [ "$(id -u)" = 0 ]; then P=/usr/local; else P="$HOME/.local"; fi
install -Dm755 pgdemo "$P/bin/pgdemo"
install -Dm644 pgdemo.png "$P/share/icons/hicolor/512x512/apps/pgdemo.png"
install -Dm644 pgdemo.desktop "$P/share/applications/pgdemo.desktop"
echo "Installed in $P (start: pgdemo, or from the applications menu)."
